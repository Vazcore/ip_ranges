<h1> IP Range </h1>

## Setting pattern for php code

[[https://github.com/Vazcore/ip_ranges/blob/master/test_ranges/set_pattern.png]]
